const path = require('path');

module.exports = {
  reactStrictMode: true,
  sassOptions: {
    includePaths: [path.join(__dirname, 'css')],
  },
  trailingSlash: true,
  devIndicators: {
    buildActivity: false,
  },
  eslint: {
    ignoreDuringBuilds: false,
  },
};
module.exports = {
  images: {
    formats: ['image/avif', 'image/webp'],
  },
};
module.exports = {
  swcMinify: true,
};
module.exports = {
  experimental: {
    runtime: 'nodejs',
    serverComponents: true,
  },
};
