"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app.server";
exports.ids = ["pages/_app.server"];
exports.modules = {

/***/ "./node_modules/next/dist/pages/_app.server.js":
/*!*****************************************************!*\
  !*** ./node_modules/next/dist/pages/_app.server.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\nObject.defineProperty(exports, \"__esModule\", ({\n    value: true\n}));\nexports[\"default\"] = AppServer;\nfunction AppServer({ children  }) {\n    return children;\n} //# sourceMappingURL=_app.server.js.map\n\nexports.__next_rsc__ = {\n      __webpack_require__,\n      _: () => {\n        \n      },\n      server: true\n    }\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L3BhZ2VzL19hcHAuc2VydmVyLmpzLmpzIiwibWFwcGluZ3MiOiJBQUFhO0FBQ2IsOENBQTZDO0FBQzdDO0FBQ0EsQ0FBQyxFQUFDO0FBQ0Ysa0JBQWU7QUFDZixxQkFBcUIsV0FBVztBQUNoQztBQUNBLEVBQUU7O0FBRUYsb0JBQW9CO0FBQ3BCLE1BQU0sbUJBQW1CO0FBQ3pCO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL3NhbXBsZV9hcHAvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L3BhZ2VzL19hcHAuc2VydmVyLmpzP2JkNzEiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzLmRlZmF1bHQgPSBBcHBTZXJ2ZXI7XG5mdW5jdGlvbiBBcHBTZXJ2ZXIoeyBjaGlsZHJlbiAgfSkge1xuICAgIHJldHVybiBjaGlsZHJlbjtcbn0gLy8jIHNvdXJjZU1hcHBpbmdVUkw9X2FwcC5zZXJ2ZXIuanMubWFwXG5cbmV4cG9ydHMuX19uZXh0X3JzY19fID0ge1xuICAgICAgX193ZWJwYWNrX3JlcXVpcmVfXyxcbiAgICAgIF86ICgpID0+IHtcbiAgICAgICAgXG4gICAgICB9LFxuICAgICAgc2VydmVyOiB0cnVlXG4gICAgfVxuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./node_modules/next/dist/pages/_app.server.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./node_modules/next/dist/pages/_app.server.js"));
module.exports = __webpack_exports__;

})();